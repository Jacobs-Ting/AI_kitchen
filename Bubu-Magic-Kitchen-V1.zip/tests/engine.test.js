import {test} from 'node:test';import assert from 'node:assert/strict';import {recommend,splitIngredients} from '../js/recipe-engine.js';import {recipes} from '../js/recipe-data.js';import {remoteRecipeGenerator} from '../js/ai-service.js';
const base={ingredients:['雞蛋','番茄','豆腐','牛奶','馬鈴薯'],methods:['微波爐'],servings:2,time:15,flavor:'家常',excluded:[]};
test('32道完整且唯一食譜',()=>{assert.ok(recipes.length>=30);assert.equal(new Set(recipes.map(r=>r.id)).size,recipes.length);for(const r of recipes){assert.ok(r.steps.length>=4);assert.ok(r.ingredients.length);assert.ok(r.tips)}});
test('微波限制及時間為硬性篩選',()=>{const r=recommend(base);assert.ok(r.length);assert.ok(r.every(x=>x.methods.every(m=>m==='微波爐')&&x.cookingTime<=15))});
test('排除奶類包含起司，排除蛋不會被分數抵銷',()=>{const r=recommend({...base,excluded:['牛奶','蛋']});assert.ok(r.every(x=>x.ingredients.every(i=>!['牛奶','起司','奶油','雞蛋'].includes(i.name))))});
test('空食材與空方式無結果',()=>{assert.deepEqual(recommend({...base,ingredients:[]}),[]);assert.deepEqual(recommend({...base,methods:[]}),[])});
test('分隔符、重複與別名',()=>assert.deepEqual(splitIngredients('蛋、蕃茄，雞蛋\n豆腐'),['雞蛋','番茄','豆腐']));
test('食材改變結果，缺少清單與份數存在',()=>{const a=recommend({...base,ingredients:['雞蛋']});const b=recommend({...base,ingredients:['豆腐']});assert.notEqual(a[0].id,b[0].id);assert.ok(a.every(r=>r.available.length+r.missing.length===r.ingredients.length&&r.requestedServings===2))});
test('遠端接口禁止網路呼叫',async()=>assert.rejects(remoteRecipeGenerator,/未實作/));

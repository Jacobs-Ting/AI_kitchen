@echo off
cd /d "%~dp0"
where node >nul 2>nul
if not errorlevel 1 goto launch
if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" (
  set "BUBU_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
  goto ready
)
echo Please install Node.js from https://nodejs.org and try again.
pause
exit /b 1
:launch
set "BUBU_NODE=node"
:ready
start "" "http://127.0.0.1:4173"
"%BUBU_NODE%" preview.mjs
pause

import {recommend} from './recipe-engine.js';
export const CONFIG=Object.freeze({useMockAI:true,apiEndpoint:null});
export async function mockRecipeGenerator(preferences){return recommend(preferences)}
export async function remoteRecipeGenerator(){throw new Error('V1尚未實作遠端AI服務，未發出任何網路請求。')}
export async function generateRecipes(preferences){return CONFIG.useMockAI?mockRecipeGenerator(preferences):remoteRecipeGenerator(preferences)}
